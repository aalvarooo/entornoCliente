document.addEventListener("DOMContentLoaded", function () {
    const tableroJuego = document.querySelector('.tablero-juego'); // Obtiene el tablero del juego.
    const barcosTotales = 2; // Define el número total de barcos del juego para hundir.
    let barcosHundidos = 0; // Contador para los barcos hundidos.
    const totalCeldas = 100; // El total de celdas en el tablero.

    function crearCelda(id) { // Crea y devuelve una celda con un ID único.
        const celda = document.createElement("div");
        celda.classList.add('celda');
        celda.id = id;
        return celda;
    }

    function generarBotesAleatorios() { // Genera posiciones aleatorias para los barcos.
        const posicionesAleatorias = [];

        while (posicionesAleatorias.length < barcosTotales) {
            const numAleatorio = Math.floor(Math.random() * totalCeldas) + 1;
            if (!posicionesAleatorias.includes(numAleatorio)) {
                posicionesAleatorias.push(numAleatorio);
            }
        }

        return posicionesAleatorias;
    }


    function colocarBotesEnTablero() { // Coloca los barcos en el tablero.
        const botePosiciones = generarBotesAleatorios();

        for (let i = 0; i < totalCeldas; i++) { // Recorre todas las celdas del tablero.
            const celda = crearCelda(i + 1); // Crea una celda en el tablero con su ID 

            if (botePosiciones.includes(i + 1)) { // Comprueba si la celda actual {i +1} está en la lista de posiciones de los barcos.
                celda.classList.add('bote');  // Si lo está le añade la clase bote
            }

            celda.addEventListener("click", alHacerClick); // Le asigna un manejador de eventos si el usuario del juego da click a una de las celdas
            tableroJuego.appendChild(celda);
        }
    }

    function alHacerClick(e) { // Maneja la interacción al hacer clic en una celda.
        const celda = e.target;

        if (celda.classList.contains('bote')) {
            alert("¡Hundido!");
            celda.classList.add('hundido');
            barcosHundidos++;
            if (barcosHundidos === barcosTotales) {
                finJuego();
            }
        } else {
            celda.classList.add('agua');
            alert("¡Agua!");
        }
    }

    function reiniciarJuego() { // Reinicia el juego.
        tableroJuego.classList.remove("juego-terminado");
        barcosHundidos = 0;
        tableroJuego.innerHTML = '';
        colocarBotesEnTablero();
    }

    function finJuego() { // Finaliza el juego cuando todos los barcos son hundidos.
        const mensajeFinJuego = document.createElement("div");
        mensajeFinJuego.classList.add("mensaje-fin-juego");
        mensajeFinJuego.innerText = "¡Has hundido todos los barcos!";

        const imagenFinJuego = document.createElement("img");
        imagenFinJuego.src = "img/gameOver.png";
        imagenFinJuego.classList.add("imagen-fin-juego");

        const botonReiniciar = document.createElement("button");
        botonReiniciar.className = "boton-reinicio";
        botonReiniciar.innerHTML = "Reiniciar juego";
        botonReiniciar.addEventListener("click", reiniciarJuego);

        tableroJuego.innerHTML = ''; //Esto borra todo el contenido que tenía tableroJuego. Se emplea para limpiar el tablero antes de mostrar una vez has terminado el juego
        tableroJuego.classList.add("juego-terminado");
        tableroJuego.appendChild(mensajeFinJuego);
        tableroJuego.appendChild(imagenFinJuego);
        tableroJuego.appendChild(botonReiniciar);
    }

    colocarBotesEnTablero();
});
